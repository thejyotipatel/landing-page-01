import DemoComponent from "./DemoComponent";


function App() {
  return (
    <div>
   <DemoComponent />
    </div>
  );
}

export default App;
